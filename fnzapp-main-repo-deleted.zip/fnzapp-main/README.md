# Summer of Tech Bootcamp App

Clone this repo, then 
```
npm install
npm start
```

And follow the instructions on the Proxy Help page, if you haven't set up your local proxy yet.

Go to ./docs/guide.md for the walkthrough.
