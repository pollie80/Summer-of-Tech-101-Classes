window.env = {
  "FNZ_API_URL": "http://localhost:6767"
};