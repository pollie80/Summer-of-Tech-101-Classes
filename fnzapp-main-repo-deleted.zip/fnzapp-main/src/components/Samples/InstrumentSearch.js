const InstrumentSearch = {
    key: 'instrument',
    title: 'Instrument Search Worked Example',
    content: `    
    `
}

export default InstrumentSearch;